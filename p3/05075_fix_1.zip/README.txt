how to compile:
make
how to run:
export PATH=$PATH:`pwd`
./p3 10
# note: can be any integers from 1 to 10
